document.addEventListener('DOMContentLoaded', () => {
    const signinForm = document.getElementById('signinForm');
    const message = document.getElementById('message');
  
    signinForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const username = document.getElementById('username').value;
      const password = document.getElementById('password').value;
  
      const response = await fetch('/signin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
      });
  
      const data = await response.json();
      message.textContent = data.message;
      if (response.ok) {
        // Redirect to the home page if sign-in is successful
        window.location.href = '/home.html'; // Replace 'home.html' with the desired URL of your home page
      }
      signinForm.reset();
    });
  });
  