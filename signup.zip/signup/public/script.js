document.addEventListener('DOMContentLoaded', () => {
  console.log('DOM loaded.'); // Check if this message appears in the browser console.

  const signupForm = document.getElementById('signupForm');
  const message = document.getElementById('message');

  signupForm.addEventListener('submit', async (event) => {
    event.preventDefault(); // Ensure this line prevents the default form submission.

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    const response = await fetch('/signup', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      
      body: JSON.stringify({ username, password })
    });

    const data = await response.json();
    message.textContent = data.message;
    signupForm.reset();console.log("kgkadlgkld");
  });
});
