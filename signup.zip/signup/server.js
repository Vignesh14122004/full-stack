const express = require('express');
const { MongoClient } = require('mongodb');
const path = require('path');
const cors = require('cors'); // Import the 'cors' module

const app = express();
const port = 3000;
const url = 'mongodb://127.0.0.1:27017/';
const dbName = 'mydb';

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(cors()); // Use 'cors' middleware for all routes

// ... (rest of the code as provided earlier)

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});



// ... (rest of the code as provided earlier)

app.post('/signup', async (req, res) => {
  const { username, password } = req.body;
  console.log('Signup request received:', { username, password }); // Check if data is received

  try {
    const client = await MongoClient.connect(url, { useUnifiedTopology: true });
    const dbo = client.db(dbName);
    const userObj = { username, password };

    const result = await dbo.collection('users').insertOne(userObj);
    console.log('Data inserted:', result.insertedCount); // Check if data is inserted
    client.close();

    res.json({ message: `${result.insertedCount} user signed up` });
  } catch (err) {
    console.error('Error during signup:', err);
    res.status(500).json({ message: 'An error occurred during signup' });
  }
});

// ... (rest of the code as provided earlier)




// ... (rest of the code as provided earlier)

app.post('/signin', async (req, res) => {
  const { username, password } = req.body;

  try {
    const client = await MongoClient.connect(url, { useUnifiedTopology: true });
    const dbo = client.db(dbName);

    // Assuming the collection 'users' contains signup data with 'username' and 'password' fields
    const user = await dbo.collection('users').findOne({ username, password });
    client.close();

    if (user) {
      res.json({ message: 'Signin successful' });
    } else {
      res.status(401).json({ message: 'Invalid credentials' });
    }
  } catch (err) {
    console.error('Error during signin:', err);
    res.status(500).json({ message: 'An error occurred during signin' });
  }
});

// ... (rest of the code as provided earlier)
